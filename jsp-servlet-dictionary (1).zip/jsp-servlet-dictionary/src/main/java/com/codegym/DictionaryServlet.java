package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DictionaryServlet", urlPatterns = {"/translate"})
public class DictionaryServlet extends HttpServlet {

    private final Map<String, String> dictionary = new HashMap<>();

    @Override
    public void init() throws ServletException {
        dictionary.put("hello", "Xin chào");
        dictionary.put("how", "Thế nào");
        dictionary.put("book", "Quyển sách");
        dictionary.put("computer", "Máy tính");
        dictionary.put("student", "Sinh viên");
        dictionary.put("school", "Trường học");
        dictionary.put("apple", "Quả táo");
        dictionary.put("beautiful", "Xinh đẹp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String searchWord = request.getParameter("word");
        String normalizedWord = searchWord == null ? "" : searchWord.trim();
        String meaning = dictionary.get(normalizedWord.toLowerCase());

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"vi\"><head><meta charset=\"UTF-8\">");
            out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            out.println("<title>Kết quả tra cứu</title>");
            out.println("<style>");
            out.println("body{font-family:Arial,sans-serif;background:#f1f5f9;margin:0;min-height:100vh;display:grid;place-items:center;color:#172554}");
            out.println(".card{background:#fff;width:min(90%,420px);box-sizing:border-box;padding:36px;border-radius:16px;box-shadow:0 12px 32px #0f172a18;text-align:center}");
            out.println("h1{font-size:25px;margin-top:0}.success{color:#15803d}.error{color:#dc2626}");
            out.println(".btn{display:inline-block;margin-top:20px;padding:12px 20px;background:#1d4ed8;color:#fff;text-decoration:none;border-radius:8px}");
            out.println("</style></head><body><main class=\"card\">");
            out.println("<h1>Kết quả tra cứu</h1>");

            if (normalizedWord.isEmpty()) {
                out.println("<p class=\"error\">Vui lòng nhập từ khóa hợp lệ!</p>");
            } else if (meaning != null) {
                out.println("<p>Từ tiếng Anh: <strong>" + escapeHtml(normalizedWord) + "</strong></p>");
                out.println("<h2 class=\"success\">" + escapeHtml(meaning) + "</h2>");
            } else {
                out.println("<h2 class=\"error\">Không tìm thấy từ: " + escapeHtml(normalizedWord) + "</h2>");
            }

            out.println("<a class=\"btn\" href=\"index.jsp\">Quay lại tìm kiếm</a>");
            out.println("</main></body></html>");
        }
    }

    private String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
