<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Từ điển Anh - Việt</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #eff6ff, #f8fafc);
            color: #172554;
        }
        .dictionary-container {
            background: #fff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 12px 32px rgba(15, 23, 42, .10);
            text-align: center;
            width: 100%;
            max-width: 420px;
        }
        .book-icon { font-size: 42px; margin-bottom: 12px; }
        h1 { color: #1d4ed8; font-size: 27px; margin: 0 0 10px; }
        p { color: #64748b; line-height: 1.5; }
        input {
            padding: 13px 14px;
            margin: 16px 0 12px;
            width: 100%;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 16px;
        }
        input:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button {
            background: #1d4ed8;
            color: white;
            padding: 13px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-weight: bold;
            font-size: 16px;
        }
        button:hover { background: #1e40af; }
        .examples { font-size: 13px; margin-top: 18px; }
    </style>
</head>
<body>
    <main class="dictionary-container">
        <div class="book-icon" aria-hidden="true">📘</div>
        <h1>Từ điển Anh - Việt</h1>
        <p>Nhập một từ tiếng Anh để tra nghĩa tiếng Việt.</p>
        <form action="translate" method="POST">
            <input type="text" name="word" placeholder="Ví dụ: hello, book, computer"
                   aria-label="Từ tiếng Anh" required autofocus>
            <button type="submit">Tìm kiếm</button>
        </form>
        <p class="examples">Từ có sẵn: hello, how, book, computer, student, school, apple, beautiful.</p>
    </main>
</body>
</html>
