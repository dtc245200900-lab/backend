# Từ điển Anh - Việt (JSP/Servlet)

Dự án Maven Webapp sử dụng Java 17, Jakarta Servlet 6.0 và tương thích Tomcat 10.1+.

## Chạy dự án

1. Cài Java 17, Maven và Apache Tomcat 10.1+.
2. Mở terminal tại thư mục dự án.
3. Đóng gói ứng dụng:

   ```bash
   mvn clean package
   ```

4. Sao chép `target/jsp-servlet-dictionary.war` vào thư mục `webapps` của Tomcat.
5. Khởi động Tomcat và truy cập:
   `http://localhost:8080/jsp-servlet-dictionary/`

## Từ vựng mẫu

- hello — Xin chào
- how — Thế nào
- book — Quyển sách
- computer — Máy tính
- student — Sinh viên
- school — Trường học
- apple — Quả táo
- beautiful — Xinh đẹp
