# Product Discount Calculator

Ứng dụng Java Web dùng JSP/Servlet, Maven, Java 17 và Tomcat 10.1+.

## Chạy ứng dụng

1. Cài Java 17, Maven và Apache Tomcat 10.1+.
2. Mở terminal tại thư mục chứa `pom.xml`.
3. Chạy `mvn clean package`.
4. Sao chép `target/product-discount-calculator.war` vào thư mục `webapps` của Tomcat.
5. Khởi động Tomcat và truy cập:
   `http://localhost:8080/product-discount-calculator/`

## Công thức

- Discount Amount = List Price × Discount Percent × 0.01
- Discount Price = List Price − Discount Amount

Tỷ lệ chiết khấu hợp lệ từ 0 đến 100%.
