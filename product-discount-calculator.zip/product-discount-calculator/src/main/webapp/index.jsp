<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Discount Calculator</title>
    <style>
        *{box-sizing:border-box}
        body{font-family:Arial,sans-serif;background:linear-gradient(135deg,#eff6ff,#f8fafc);margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;color:#172554}
        .card{background:#fff;padding:36px;border-radius:16px;box-shadow:0 12px 32px rgba(15,23,42,.10);width:min(100%,460px)}
        h1{font-size:26px;color:#1d4ed8;margin:0 0 8px}
        p{color:#64748b;line-height:1.5}
        label{display:block;font-weight:bold;margin-top:18px;margin-bottom:8px}
        input{width:100%;padding:12px 14px;border:1px solid #cbd5e1;border-radius:8px;font-size:16px}
        input:focus{outline:2px solid #93c5fd;border-color:#2563eb}
        button{width:100%;margin-top:24px;padding:13px;background:#1d4ed8;color:white;border:0;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer}
        button:hover{background:#1e40af}
    </style>
</head>
<body>
    <main class="card">
        <h1>Product Discount Calculator</h1>
        <p>Nhập thông tin sản phẩm để tính số tiền chiết khấu và giá sau giảm.</p>
        <form action="display-discount" method="POST">
            <label for="description">Product Description</label>
            <input id="description" type="text" name="description" placeholder="Tên hoặc mô tả sản phẩm" required>

            <label for="price">List Price</label>
            <input id="price" type="number" name="price" min="0" step="0.01" placeholder="Ví dụ: 100000" required>

            <label for="discount">Discount Percent (%)</label>
            <input id="discount" type="number" name="discount" min="0" max="100" step="0.01" placeholder="Ví dụ: 15" required>

            <button type="submit">Calculate Discount</button>
        </form>
    </main>
</body>
</html>
