package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DiscountServlet", urlPatterns = {"/display-discount"})
public class DiscountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String description = request.getParameter("description");
        String listPriceText = request.getParameter("price");
        String discountPercentText = request.getParameter("discount");

        try {
            if (description == null || description.trim().isEmpty()) {
                throw new IllegalArgumentException("Vui lòng nhập mô tả sản phẩm.");
            }

            BigDecimal listPrice = new BigDecimal(listPriceText);
            BigDecimal discountPercent = new BigDecimal(discountPercentText);

            if (listPrice.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException("Giá niêm yết không được âm.");
            }
            if (discountPercent.compareTo(BigDecimal.ZERO) < 0
                    || discountPercent.compareTo(new BigDecimal("100")) > 0) {
                throw new IllegalArgumentException("Tỷ lệ chiết khấu phải từ 0 đến 100.");
            }

            BigDecimal discountAmount = listPrice
                    .multiply(discountPercent)
                    .multiply(new BigDecimal("0.01"))
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal discountPrice = listPrice
                    .subtract(discountAmount)
                    .setScale(2, RoundingMode.HALF_UP);

            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html><html lang=\"vi\"><head><meta charset=\"UTF-8\">");
                out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
                out.println("<title>Discount Result</title><style>");
                out.println("body{font-family:Arial,sans-serif;background:#f1f5f9;margin:0;min-height:100vh;display:grid;place-items:center;color:#172554;padding:20px;box-sizing:border-box}");
                out.println(".card{background:white;padding:36px;border-radius:16px;box-shadow:0 12px 32px #0f172a18;width:min(100%,480px);box-sizing:border-box}");
                out.println("h1{color:#1d4ed8;margin-top:0}.row{padding:12px 0;border-bottom:1px solid #e2e8f0;overflow-wrap:anywhere}");
                out.println(".amount{color:#15803d;font-size:20px;font-weight:bold}.btn{display:inline-block;margin-top:22px;padding:12px 18px;background:#1d4ed8;color:white;text-decoration:none;border-radius:8px}");
                out.println(".error{color:#dc2626;font-weight:bold}</style></head><body><main class=\"card\">");
                out.println("<h1>Kết quả tính chiết khấu</h1>");
                out.println("<div class=\"row\"><strong>Product Description:</strong> " + escapeHtml(description.trim()) + "</div>");
                out.println("<div class=\"row\"><strong>List Price:</strong> " + listPrice.toPlainString() + "</div>");
                out.println("<div class=\"row\"><strong>Discount Percent:</strong> " + discountPercent.toPlainString() + "%</div>");
                out.println("<div class=\"row\"><strong>Discount Amount:</strong> <span class=\"amount\">" + discountAmount.toPlainString() + "</span></div>");
                out.println("<div class=\"row\"><strong>Discount Price:</strong> <span class=\"amount\">" + discountPrice.toPlainString() + "</span></div>");
                out.println("<a class=\"btn\" href=\"index.jsp\">Quay lại</a>");
                out.println("</main></body></html>");
            }
        } catch (NumberFormatException ex) {
            showError(response, "Vui lòng nhập giá và tỷ lệ chiết khấu hợp lệ.");
        } catch (IllegalArgumentException ex) {
            showError(response, ex.getMessage());
        }
    }

    private void showError(HttpServletResponse response, String message) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html lang=\"vi\"><head><meta charset=\"UTF-8\"><title>Lỗi nhập liệu</title></head>");
            out.println("<body style=\"font-family:Arial,sans-serif;text-align:center;margin:80px 20px\">");
            out.println("<h2 style=\"color:#dc2626\">" + escapeHtml(message) + "</h2>");
            out.println("<a href=\"index.jsp\">Quay lại biểu mẫu</a></body></html>");
        }
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;")
                    .replace(">", "&gt;").replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
