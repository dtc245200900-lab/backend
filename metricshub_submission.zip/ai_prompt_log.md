# AI Prompt Log — MetricsHub

## Prompt 1: Audit lựa chọn layout
**Prompt:** Phân tích các lỗi kiến trúc trong Navbar dùng CSS Grid với cột pixel cố định, Dashboard dùng Flexbox lồng sâu và Pricing tự viết media query. Đề xuất công cụ phù hợp cho từng vùng.

**Tóm tắt sử dụng:** Chọn Flexbox cho Navbar vì bố cục một chiều và nội dung thay đổi theo ngôn ngữ; CSS Grid cho Dashboard hai chiều và widget có thể span nhiều track; Bootstrap Grid cho ba thẻ Pricing responsive.

## Prompt 2: Grid span và Bento Dashboard
**Prompt:** Cho ví dụ CSS Grid dùng `grid-column: span 2` và `grid-row: span 2`, đồng thời giữ tất cả widget là phần tử con trực tiếp của một grid container.

**Tóm tắt sử dụng:** Tạo `.dashboard-grid` với ba cột trên desktop; Revenue overview chiếm hai cột, Traffic sources chiếm hai hàng. Trên tablet chuyển sang hai cột và trên mobile về một cột.

## Prompt 3: Responsive Navbar
**Prompt:** Làm sao để Navbar xử lý nhãn dài như tiếng Đức mà không dùng các cột pixel cố định?

**Tóm tắt sử dụng:** Dùng `display: flex`, `gap`, `flex-wrap: wrap`, `flex: 1 1 320px` và `white-space: nowrap` cho từng liên kết để các nhóm có thể bố trí lại khi thiếu chỗ.

## Prompt 4: Bootstrap Pricing
**Prompt:** Giải thích cách dùng `row`, `col-12 col-md-4`, `card` và `card-body` để tạo ba thẻ giá xếp chồng trên điện thoại và thành ba cột trên desktop.

**Tóm tắt sử dụng:** Áp dụng Bootstrap 5 Grid; mỗi cột chiếm 12/12 ở breakpoint nhỏ và 4/12 từ `md` trở lên.

## Prompt 5: Flexbox, Grid và gap
**Prompt:** Flexbox và CSS Grid có thể kết hợp trong cùng trang không? Khi nào dùng `gap` thay cho margin?

**Tóm tắt sử dụng:** Kết hợp Grid cho layout tổng thể và Flexbox cho căn chỉnh thành phần bên trong. Dùng `gap` để chuẩn hóa khoảng cách giữa các item mà không tạo margin chồng lấn.

## Kiểm thử thủ công
- Desktop: Navbar, bốn KPI, Bento dashboard và ba cột Pricing.
- Tablet (khoảng 768px): KPI chuyển thành hai cột; Dashboard chuyển thành hai cột.
- Mobile (375px): KPI và widget xếp một cột; Pricing dùng `col-12`; Navbar có thể xuống dòng.
