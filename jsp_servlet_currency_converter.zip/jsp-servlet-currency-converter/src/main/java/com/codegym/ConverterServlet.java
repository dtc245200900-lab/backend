package com.codegym;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ConverterServlet", urlPatterns = {"/convert"})
public class ConverterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String rateText = request.getParameter("rate");
        String usdText = request.getParameter("usd");

        try {
            if (rateText == null || usdText == null || rateText.isBlank() || usdText.isBlank()) {
                throw new IllegalArgumentException("Vui lòng nhập đầy đủ tỉ giá và lượng USD.");
            }
            double rate = Double.parseDouble(rateText);
            double usd = Double.parseDouble(usdText);
            if (!Double.isFinite(rate) || !Double.isFinite(usd) || rate <= 0 || usd < 0) {
                throw new IllegalArgumentException("Tỉ giá phải lớn hơn 0 và lượng USD không được âm.");
            }

            double vnd = rate * usd;
            NumberFormat fmt = NumberFormat.getNumberInstance(new Locale("vi", "VN"));
            fmt.setMaximumFractionDigits(2);

            try (var out = response.getWriter()) {
                out.println("<!doctype html><html lang='vi'><head><meta charset='UTF-8'>");
                out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
                out.println("<title>Kết quả chuyển đổi</title>");
                out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>");
                out.println("<style>body{background:#f3f6fb}.result{max-width:600px;margin:8vh auto;border:0;border-radius:18px;box-shadow:0 12px 35px #15264a18}</style>");
                out.println("</head><body><main class='container'><section class='card result'><div class='card-body p-4 p-md-5'>");
                out.println("<p class='text-primary fw-bold'>CURRENCY CONVERTER</p><h1 class='h3 mb-4'>Kết quả chuyển đổi</h1>");
                out.println("<p class='text-secondary mb-1'>Tỉ giá</p><p class='fs-5'>" + fmt.format(rate) + " VNĐ/USD</p>");
                out.println("<p class='text-secondary mb-1'>Số tiền USD</p><p class='fs-5'>$" + fmt.format(usd) + "</p>");
                out.println("<div class='alert alert-success mt-4'><div class='small'>Thành tiền VNĐ</div><strong class='fs-3'>" + fmt.format(vnd) + " VNĐ</strong></div>");
                out.println("<a class='btn btn-primary mt-2' href='index.jsp'>Chuyển đổi tiếp</a>");
                out.println("</div></section></main></body></html>");
            }
        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            try (var out = response.getWriter()) {
                out.println("<!doctype html><html lang='vi'><head><meta charset='UTF-8'><title>Lỗi nhập liệu</title>");
                out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'></head>");
                out.println("<body class='bg-light'><main class='container py-5'><div class='alert alert-danger'>");
                out.println("<h1 class='h4'>Không thể chuyển đổi</h1><p>" + escapeHtml(e.getMessage()) + "</p>");
                out.println("<a href='index.jsp' class='btn btn-primary'>Quay lại</a></div></main></body></html>");
            }
        }
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                    .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
