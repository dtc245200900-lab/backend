<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chuyển đổi USD sang VNĐ</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{min-height:100vh;background:linear-gradient(135deg,#edf4ff,#f8fafc)}
    .converter-card{max-width:520px;width:100%;border:0;border-radius:20px;box-shadow:0 18px 50px rgba(24,48,88,.12)}
    .brand-mark{width:48px;height:48px;display:grid;place-items:center;border-radius:14px;background:#0d6efd;color:#fff;font-size:1.4rem;font-weight:700}
    .form-control{padding:.8rem 1rem}
  </style>
</head>
<body class="d-flex align-items-center py-5">
<main class="container d-flex justify-content-center">
  <section class="card converter-card">
    <div class="card-body p-4 p-md-5">
      <div class="brand-mark mb-4">$</div>
      <p class="text-primary fw-bold small mb-2">CURRENCY CONVERTER</p>
      <h1 class="h2 fw-bold mb-2">Chuyển đổi USD sang VNĐ</h1>
      <p class="text-secondary mb-4">Nhập tỉ giá và số USD để tính số tiền tương ứng.</p>
      <form action="${pageContext.request.contextPath}/convert" method="post">
        <div class="mb-3">
          <label for="rate" class="form-label fw-semibold">Tỉ giá (VNĐ/USD)</label>
          <input type="number" class="form-control" id="rate" name="rate" value="25000" min="0.000001" step="any" required>
          <div class="form-text">Ví dụ: 25000 VNĐ cho mỗi USD.</div>
        </div>
        <div class="mb-4">
          <label for="usd" class="form-label fw-semibold">Lượng USD cần đổi</label>
          <input type="number" class="form-control" id="usd" name="usd" placeholder="Nhập số USD" min="0" step="any" required>
        </div>
        <button type="submit" class="btn btn-primary btn-lg w-100">Chuyển đổi tiền tệ</button>
      </form>
    </div>
    <div class="card-footer bg-white border-0 text-center text-secondary small pb-4">Bài thực hành Java Servlet · Maven · Tomcat 10.1+</div>
  </section>
</main>
</body>
</html>
