# JSP Servlet Currency Converter

- Java 17, Maven, Jakarta Servlet API 6.0, Apache Tomcat 10.1+
- Form JSP gửi `rate` và `usd` bằng POST tới `/convert`.
- Servlet tính `VND = USD * Rate`.

## Chạy thử
1. Cài JDK 17, Maven và Tomcat 10.1+.
2. Mở terminal tại thư mục có `pom.xml`.
3. Chạy `mvn clean package`.
4. Chờ `BUILD SUCCESS`; file WAR nằm tại `target/jsp-servlet-currency-converter.war`.
5. Deploy WAR lên Tomcat.
6. Mở `http://localhost:8080/jsp-servlet-currency-converter/`.
