# AI Prompt Log — CreativeChronicle

1. **Câu hỏi về CSS Grid:**  
   “Giải thích `grid-template-columns: 2fr 1fr`, `grid-row: span 2` và cách dùng chúng để tạo gallery gồm một ảnh lớn bên trái, hai ảnh nhỏ bên phải.”

   **Kết quả áp dụng:** Dùng CSS Grid với hai cột theo tỉ lệ 2:1; ảnh chính chiếm hai hàng, hai ảnh phụ nằm ở cột thứ hai.

2. **Câu hỏi về responsive:**  
   “Cách viết media query để chuyển CSS Grid mosaic từ hai cột trên desktop thành một cột trên điện thoại?”

   **Kết quả áp dụng:** Ở breakpoint dưới 768px, đổi `grid-template-columns` thành `1fr`, đặt các ảnh về hàng tự động và gán chiều cao ảnh phù hợp.

3. **Câu hỏi về Bootstrap Grid:**  
   “Giải thích `col-12 col-md-6 col-lg-3` trong Bootstrap 5.”

   **Kết quả áp dụng:** Mỗi thẻ chiếm 12 cột trên mobile, 6 cột từ breakpoint `md`, và 3 cột từ breakpoint `lg`.

4. **Câu hỏi về Flexbox utilities:**  
   “Bootstrap có class nào để căn giữa dọc, chia khoảng cách và cho phần tử xuống dòng?”

   **Kết quả áp dụng:** Dùng `d-flex`, `align-items-center`, `justify-content-between`, `flex-wrap` và `gap-3` cho thanh thông tin tác giả.
