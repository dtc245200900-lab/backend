# Layout Refactoring Report — CreativeChronicle

Trang cũ dùng `float` để xếp các thành phần, nên việc căn giữa theo chiều dọc khó kiểm soát và phần tử cha có thể không bao trọn các phần tử float nếu thiếu clearfix. `position: absolute` đưa ảnh ra khỏi luồng tài liệu bình thường; kết hợp với chiều cao cố định 400px, gallery không tự tăng chiều cao khi nội dung hoặc màn hình thay đổi, dẫn đến ảnh đè lên văn bản trên điện thoại.

Bản mới dùng Flexbox cho thanh tác giả vì đây là bố cục một chiều: `align-items: center` căn avatar, thông tin và nút chia sẻ theo trục dọc; `flex-wrap` cho phép xuống dòng khi thiếu chỗ. Mosaic Gallery dùng CSS Grid với hai cột `2fr 1fr`; ảnh chính chiếm hai hàng bằng `grid-row: span 2`. Ở màn hình nhỏ, Grid chuyển thành một cột. Khu vực bài viết đề xuất dùng Bootstrap Grid: `col-12 col-md-6 col-lg-3`, lần lượt hiển thị một, hai hoặc bốn thẻ mỗi hàng.
